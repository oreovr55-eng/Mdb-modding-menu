package com.mdb.standalone

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var panel: LinearLayout
    private lateinit var hint: TextView
    private var menuOpen = true
    private val states = linkedMapOf("FLY" to false, "SPEED" to false, "GHOST" to false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildMenu()
        updateMenu()
    }

    private fun buildMenu() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 20, 28, 20)
            setBackgroundColor(0xFF090909.toInt())
        }

        val title = TextView(this).apply {
            text = "MDB  •  MOD MENU"
            textSize = 28f
            setTextColor(0xFFFF3030.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
        }
        page.addView(title)

        hint = TextView(this).apply {
            text = "Standalone demo • Press controller X to hide/show"
            textSize = 14f
            setTextColor(0xFFDDDDDD.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 4, 8, 18)
        }
        page.addView(hint)

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 12, 16, 12)
            setBackgroundColor(0xFF191919.toInt())
        }

        states.keys.forEach { feature ->
            val button = Button(this).apply {
                text = "$feature: OFF"
                textSize = 18f
                setTextColor(0xFFFFFFFF.toInt())
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFB51F2A.toInt()))
                setOnClickListener {
                    states[feature] = !(states[feature] ?: false)
                    text = "$feature: ${if (states[feature] == true) "ON" else "OFF"}"
                    hint.text = "$feature changed • Demo toggle only"
                }
            }
            panel.addView(button, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 8 })
        }

        val close = Button(this).apply {
            text = "CLOSE MENU"
            setOnClickListener { setMenuVisible(false) }
        }
        panel.addView(close)

        page.addView(panel, LinearLayout.LayoutParams(520, LinearLayout.LayoutParams.WRAP_CONTENT))
        val scroll = ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun setMenuVisible(visible: Boolean) {
        menuOpen = visible
        panel.visibility = if (visible) View.VISIBLE else View.GONE
        hint.text = if (visible) "Press controller X to hide/show" else "Menu hidden • Press controller X to reopen"
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount == 0 &&
            event.keyCode == KeyEvent.KEYCODE_BUTTON_X) {
            setMenuVisible(!menuOpen)
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
