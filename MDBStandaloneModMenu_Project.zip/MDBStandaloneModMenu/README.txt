MDB STANDALONE MOD MENU — ANDROID PROJECT

This is a standalone demo app. It does NOT connect to Gorilla Tag, modify a game,
inject code, or enable cheats. FLY, SPEED, and GHOST are interface-only demo toggles.

BUILD AN APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Let Gradle sync and install the Android SDK platform 35 if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK under app/build/outputs/apk/debug/.

CONTROLLER:
The app listens for Android KEYCODE_BUTTON_X. Controller mapping can vary by
headset/controller and Android input profile.
