RED BABOON MENU - Standalone Android demo project

This project builds a standalone Android APK with a red-and-black menu.
The feature switches are visual demonstrations only. They do not modify,
control, or inject into Scary Baboon or any other game.

Build requirements:
- Android SDK platform 35
- Android Gradle Plugin 8.7.3
- Gradle 8.9
- JDK 17

The GitHub Actions workflow should unzip this archive into a folder named
'project'. The resulting project path must be:
project/MDBStandaloneModMenu/

You can use the Build Red Baboon Menu workflow to build the debug APK.
