package com.mdb.standalone

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var featurePanel: LinearLayout
    private lateinit var status: TextView

    private val features = linkedMapOf(
        "FLY" to false,
        "SPEED BOOST" to false,
        "SUPER JUMP" to false,
        "GHOST MODE" to false,
        "NIGHT VISION" to false,
        "SCARY MODE" to false
    )

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun text(
        value: String,
        size: Float,
        color: Int,
        bold: Boolean = false
    ) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(14).toFloat()
            if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 8, 11)
        window.navigationBarColor = Color.rgb(8, 8, 11)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(22))
            setBackgroundColor(Color.rgb(8, 8, 11))
        }

        root.addView(text("RED BABOON", 32f, Color.rgb(255, 55, 67), true).apply {
            gravity = Gravity.CENTER
        })

        root.addView(text("MOD MENU  •  QUEST EDITION", 12f, Color.LTGRAY, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(18))
        })

        val profile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(Color.rgb(30, 15, 19), Color.rgb(130, 35, 45))
        }
        profile.addView(text("PROJECT PROFILE", 11f, Color.rgb(255, 115, 125), true))
        profile.addView(text("STANDALONE DEMO", 19f, Color.WHITE, true).apply {
            setPadding(0, dp(5), 0, dp(3))
        })
        profile.addView(text("Not connected to Scary Baboon", 12f, Color.LTGRAY))
        root.addView(profile)

        status = text("●  MENU READY  •  DEMO SWITCHES ONLY", 12f, Color.rgb(255, 105, 115), true)
        status.gravity = Gravity.CENTER
        status.setPadding(0, dp(16), 0, dp(14))
        root.addView(status)

        featurePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(Color.rgb(20, 20, 25), Color.rgb(75, 45, 50))
        }
        root.addView(featurePanel)
        renderFeatures()

        root.addView(text(
            "STANDALONE APP • SWITCHES ARE VISUAL DEMOS",
            10f, Color.GRAY, true
        ).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        })

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })
    }

    private fun renderFeatures() {
        featurePanel.removeAllViews()
        featurePanel.addView(text("FEATURES", 13f, Color.LTGRAY, true).apply {
            setPadding(dp(4), dp(2), 0, dp(12))
        })

        features.forEach { (name, enabled) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(13), dp(14), dp(13))
                background = rounded(Color.rgb(34, 34, 40), Color.rgb(65, 65, 73))
                isClickable = true
                isFocusable = true
            }

            row.addView(text(name, 15f, Color.WHITE, true), LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            ))

            row.addView(text(if (enabled) "ON" else "OFF", 12f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(17), dp(8), dp(17), dp(8))
                background = rounded(
                    if (enabled) Color.rgb(175, 30, 45) else Color.rgb(68, 68, 76)
                )
            })

            row.setOnClickListener {
                features[name] = !(features[name] ?: false)
                status.text = "●  $name DEMO SWITCH UPDATED"
                renderFeatures()
            }

            featurePanel.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(9) })
        }

        featurePanel.addView(text("RESET ALL", 13f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(14), dp(12), dp(14))
            background = rounded(Color.rgb(110, 25, 36), Color.rgb(180, 55, 65))
            isClickable = true
            setOnClickListener {
                features.keys.forEach { features[it] = false }
                status.text = "●  ALL DEMO SWITCHES RESET"
                renderFeatures()
            }
        })
    }
}
